﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RestaurantXYZCafe.Models;
using Microsoft.EntityFrameworkCore;

namespace RestaurantXYZCafe.Controllers
{
    public class OrderController : Controller
    {
        private readonly DBConnect _db;
        public OrderController(DBConnect db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            var displaydata = _db.Orders.ToList();
            return View(displaydata);
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(NewOrders n_orders) 
        {
            if (ModelState.IsValid)
            {
                _db.Add(n_orders);
                await _db.SaveChangesAsync();
                return RedirectToAction("Index");

            }
            return View(n_orders);
        }
        public async Task<IActionResult> Edit(int? id)
        {
            if (id==null)
            {
                return RedirectToAction("Index");
            }
            var getorderdetails = await _db.Orders.FindAsync(id);
            return View(getorderdetails);
        }
        [HttpPost]
        public async Task<ActionResult> Edit(NewOrders n_orders)
        {
            if (ModelState.IsValid)
            {
                _db.Update(n_orders);
                await _db.SaveChangesAsync();
                return RedirectToAction("Index");

            }
            return View(n_orders);
        }                                                                      
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("Index");
            }
            var getorderdetails = await _db.Orders.FindAsync(id);
            return View(getorderdetails);
        }
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("Index");
            }
            var getorderdetails = await _db.Orders.FindAsync(id);
            return View(getorderdetails);
        }
        [HttpPost]

        public async Task<IActionResult> Delete(int id)
        {
           
            var getorderdetails = await _db.Orders.FindAsync(id);
            _db.Orders.Remove(getorderdetails);
            await _db.SaveChangesAsync();

            return RedirectToAction("Index");
        }
    }
}
