﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace RestaurantXYZCafe.Models
{
    public class NewOrders
    {
        [Key]
        public int o_id { get; set; }

        [Required(ErrorMessage = "Please enter Order Number")]
        [Display(Name = "Order number")]
        public int o_number { get; set; }

        [Required(ErrorMessage = "Please enter the customer name")]
        [Display(Name = "Customer")]
        public string o_customerName { get; set; }

        [Required(ErrorMessage = "Please enter the customer address")]
        [Display(Name = "Customer address")]
        public string o_customerAddress { get; set; }

        [Required(ErrorMessage = "Please enter the price")]
        [Display(Name = "Total price")]
        public double o_totalPrice { get; set; }
       

    }
}
