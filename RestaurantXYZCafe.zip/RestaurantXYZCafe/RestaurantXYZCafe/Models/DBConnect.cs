﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
namespace RestaurantXYZCafe.Models
{
    public class DBConnect:DbContext
    {
       public DBConnect(DbContextOptions<DBConnect> options):base(options)
        { 

        }
        public DbSet<NewOrders> Orders { get; set; }
    }
}
